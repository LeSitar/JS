//Task01
//Отсортировать массив users по возрасту

const users =[
    {name: 'Anna', address:{city:'Berlin', country:'Germany'}, age: 32},
    {name: 'Vasya', address:{city:'Tokio', country:'Japan'}, age: 28},
    {name: 'Mariya', address:{city:'London', country:'England'}, age: 15},
    {name: 'Mark', address:{city:'Rom', country:'Italy'}, age: 46},
    {name: 'Sofi', address:{city:'Verona', country:'Italy'}, age: 38},
    {name: 'Sergio', address:{city:'Barcelona', country:'Spain'}, age: 18}
]

const usersAgeArray = users.sort(function (a, b) {
    if (a.age > b.age){
        return 1;
    }
    if (a.age < b.age) {
        return -1
    }
    return 0;
}
)
console.log(usersAgeArray)


//Task02
/* 
[1,5,8,4,6,9,3,10];
function filterRange(array,1,4) -> [1,3,4]
 */
const arr = [1, 5, 8, 4, 6, 9, 3, 10];

function filterRange(array, a, b) {

    const result = array.filter(number => number >= a && number <= b);
    result.sort((a, b) => a - b);
    return result;
}
console.log(filterRange(arr, 1, 4));


//Task03
/* Отсортировать массив в порядке убывание
[7,3,8,9,10,2] -> [10,9,8,7,3,2]
 */

const array = [7, 3, 8, 9, 10, 2];
function compare(a, b) {
    if (a > b) return -1;
}
array.sort(compare);
console.log(array)