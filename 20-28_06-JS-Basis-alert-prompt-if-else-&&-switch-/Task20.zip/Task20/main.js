// Task 01
let num1 = +prompt('Enter the first number');
let num2 = +prompt('Enter the second number');
let sum = num1 + num2;
alert(sum);
if (sum < 10) {
    alert('the amount is too small');
} else if (sum > 10) {
    alert('the amount is too big');
} else if (sum === 10) {
    alert('Bingo!');
}
// Task 01 with "?" operator
let message = (sum < 10) ? 'the amount is too small' : (sum > 10) ? 'the amount is too big' : (sum === 10) ? 'Bingo!' : false;
console.log(message);

// Task 02
let login = prompt('Enter your login');
if (login === 'employee') {
    alert('Hi employee!');
}
else if (login === 'boss') {
    alert('"Hello boss"');
}
else if (login ==='') {
    alert('no login');
}
else {
    alert('Hi user');
}

switch (login) {
    case'boss':
        alert('"Hello boss"');
        break
    case 'employee':
        alert('Hi employee!');
        break
    case '':
        alert('no login');
        break
    default:
        alert('Hi user')
}

// Task 3
let age = +prompt('Enter your age');
if (age >= 14 && age <= 90) {
    alert('the variable age is located in the range between 14 and 90 inclusive');
}
else {
    alert('variable age is not found in the range from 14 to 90 inclusive');
}

age = +prompt('Enter your age for check');
if (age > 13 && age <=90) {
    alert('the variable age is located in the range between 14 and 90 inclusive');
}
else {
    alert('variable age is not found in the range from 14 to 90 inclusive');
}
age = +prompt('Введите ваш возраст');
if (age >= 14 && age <= 90) {
    alert('Ваш возраст в диапозоне от 14 до 90');
}
else {
    alert('Ваш возраст вне диапозона от 14 до 90')
}