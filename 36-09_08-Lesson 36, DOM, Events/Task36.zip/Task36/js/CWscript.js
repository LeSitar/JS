const input = document.querySelector('#userAnswer'),
    checkMessage = document.querySelector('#checkMessage'),
    submitBtn = document.querySelector('#button'),
    checkBtn = document.querySelector('#check_button'),
    rightWord = document.querySelector('#rightWord');


function changeMessage(message) {
    document.querySelector('#message').innerHTML = message;
}
function hide(element) {
    element.style.display = 'none';
}
function show(element) {
    element.style.display = 'block';
}


submitBtn.onclick = () => {
    changeMessage(`You word is ${input.value.length} letters`)
    hide(submitBtn);
    show(checkBtn);
    show(checkMessage);
    rightWord.innerHTML = input.value;
    input.value = '';
};
checkBtn.onclick = () => {
    
}