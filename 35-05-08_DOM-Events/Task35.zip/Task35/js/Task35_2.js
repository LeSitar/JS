const prevBtn = document.querySelector('#prevBtn'),
    nextBtn = document.querySelector('#nextBtn'),
    imgBox = document.querySelector('.img_box');



function show(element) {
    element.style.display = 'block';
}
function hide(element) {
    element.style.display = 'none';
}

prevBtn.onclick = () => {
}
nextBtn.onclick = () => {
    show(imgBox.firstElementChild);
    imgBox.removeChild(imgBox.firstChild);
}
