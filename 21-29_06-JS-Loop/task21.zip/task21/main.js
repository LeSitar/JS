// // // Task1
const rubbel = +prompt('Enter the amount in rubles');
const euro = rubbel / 87;
const dollar = rubbel / 73;
alert('Amount in euro: ' + euro.toFixed(2) + '\nAmount in dollar: ' + dollar.toFixed(2));



// //Task2

const number = +prompt('Enter the number please');
let summe = 0;
for (let i = 2; i <=number; i++){
    if (i % 2 === 0) {
        summe += i;
        console.log(i);
    }
}
alert('The sum of even numbers is: '+ summe);

// // Task3
let count = 3;
let randomNumber = parseInt(Math.random() * 20);
console.log(randomNumber);
while (count) {
    let userNumber = parseInt(prompt('Try to guess the number, enter the number'));
    count--;
    if (userNumber > randomNumber) {
        alert('The implied number is lower, you have ' + count + ' tries left');
    } else if (userNumber < randomNumber) {
        alert('The implied number is larger,you have ' + count + ' tries left');
    }
    else if (userNumber === randomNumber) {
        alert('Congratulations you won!');
        count = -1;
        break;
    }
}
if (count === 0) {
    alert('You lost, the number was: ' + randomNumber);
}

