/* Задания:

1) Удалить все рекламные блоки со страницы (правая часть сайта)

2) Изменить жанр фильма, поменять "комедия" на "драма"

3) Изменить задний фон постера с фильмом на изображение "bg.jpg". Оно лежит в папке img.
Реализовать только при помощи JS

4) Список фильмов на странице сформировать на основании данных из этого JS файла.
Отсортировать их по алфавиту 

5) Добавить нумерацию выведенных фильмов */

'use strict';

const movieDB = {
    movies: [
        "On the Rocks",
        "The Trip to Greece",
        "Bad Education",
        "The Nest",
        "Nomadland"
    ]
};


//1
const promotion = document.querySelector('.promo__adv');
let promoElements = promotion.innerHTML;
function removeBlocks() {
    while (promotion.firstChild) {
        promotion.removeChild(promotion.firstChild)
    }
}
removeBlocks();
//2
document.querySelector('.promo__bg .promo__genre').innerHTML = 'DRAMA';

//3
const bg= document.querySelector('.promo__bg');
function changeBgImg() {
    bg.style.backgroundImage = 'url(./img/bg.jpg) '
}
changeBgImg();

//4 Далее пока не решил

// const movieList = document.querySelector('.promo__interactive-list');

// const item = document.querySelector('.promo__interactive-item');
// let movieName = item.innerHTML;


