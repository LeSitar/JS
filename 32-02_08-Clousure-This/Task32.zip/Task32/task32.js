
// #32
//Task01
/* 
'hjkld fghj fhjgldhgfjlhsg shfjg shgjslg' -> 4 (вернуть длину самого короткого слова в строке)
 */


let str = 'hjkld fghj fhjgldhgfjlhsg shfjg shgjslg';

//====1 Method
function findLengthOfShortString() {
    let space = ' ';
    let array = splitString(str, space);
    function splitString(string, separator) {
    let arrayOfStrings = string.split(separator);
    return arrayOfStrings;
    }
    array.sort();
    let shortest_element = array[0];
    return shortest_element.length;
}
console.log(findLengthOfShortString(str));

// ====2 Method
// let min = Math.min.apply(Math, array.map(function(str) { return str.length; }));
// console.log(min);

//Task02
/*
function isIsgram('abcd') -> true;
function isIsogram('abbcd') -> false;
function isIsogrma('abdcA') -> false 
*/

function isIsgram(text) {
    const prototypText = 'abcd';
    return text === prototypText ? true : false;
}
console.log(isIsgram('abcd'));
console.log(isIsgram('abbcd'));
console.log(isIsgram('abdcA'));